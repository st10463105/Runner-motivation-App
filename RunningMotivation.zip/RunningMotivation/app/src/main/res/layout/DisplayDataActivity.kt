package layout

import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.activity_main.MainActivity
import com.example.runningmotivation.R
import com.example.trackacademic.MainActivity

private val Any.size: Any
    get() {}
private val Any.weekdayslist: Any
    get() {}

class DisplayDataActivity : ComponentActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.displayrecyclerview)
        val recyclerview = findViewById<RecyclerView>(R.id.recyclerview)
        val tvAverage= findViewById<TextView>(R.id.tvAvg)

        recyclerview.layoutManager= LinearLayoutManager(this)
        recyclerview.adapter= RunnerAdapter (MainActivity.weekdayslist)

        // calculate AVG
        if(MainActivity.weekdayslist.isNotEmpty())
        {
            val totalmarks = MainActivity.weekdayslist.sumOf { it.kilometers.toDouble() }
            val calAVG= totalmarks/MainActivity.weekdayslist.size
            tvAverage.text="Average Marks %.2f".format(calAVG)

        }
        else {
            tvAverage.text="No data "
        }

    }

    private fun RunnerAdapter(Kilometre: Array<String>): RunnerAdapter {

    }

}