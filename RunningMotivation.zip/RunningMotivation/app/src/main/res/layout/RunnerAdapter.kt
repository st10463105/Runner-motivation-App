package layout

import com.example.activity_main.runnerAdater

package com.example.trackacademic

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RunnerAdapter(private val Kilometre:  Array<String>, private val Runs: Array<Int>) :
     RecyclerView.Adapter<runnerAdater.RunsViewHolder>() {

    /* View Holder to holder each items */

         class RunsViewHolder(itemview: View, kilometre: Int, itemsView: View) : RecyclerView.ViewHolder(itemsView) {
             val kelometerTextView: Any
             val dayTextView: TextView = itemView.findViewById(dayTextView)
             val kilometreTextView: TextView = itemView.findViewById(kilometre)

         }

     override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RunsViewHolder  {

            val view = LayoutInflater.from(parent.context)
            return RunsViewHolder(view,)

    }

    override fun onCreateViewHolder(holder: RunsViewHolder,  position: Int  {

        holder.dayTextView.text = Runs[position]
        holder.kelometerTextView. = Runs intArrayOf(position)



}