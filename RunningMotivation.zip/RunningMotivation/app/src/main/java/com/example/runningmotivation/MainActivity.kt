package com.example.activity_main


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.runningmotivation.R


class MainActivity : ComponentActivity() {

    private val Days = arrayOf( "Monday","Tuesday", "Wedneday","Thursday","Friday", "Saturday","Sunday",)
    private val kilometre = arrayOf(5, 10, 15, 20, 25, 30, 35)

    class LinerLayoutManager(mainActivity: MainActivity) : RecyclerView.LayoutManager() {

    }

    private fun runnerAdapter(days: Array<String>, kilometre: Nothing?): Any {

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val totalkilometre = kilometre.sum()

        // Set total runner to the text view

        val totalTextView: TextView = findViewById<EditText>(R.id.runtotalTextView)
        totalTextView.text = "Total kilometre: $totalkilometre"

        val recyclerview: RecyclerView = findViewById(R.id.runtotalTextView)
        recyclerview.layoutManager = LinerLayoutManager(this)
        val Kilometre = null
        val recycleView
        recycleView.adapter = runnerAdapter(Days, Kilometre)

        val itemsView = null

        class RunnerAdapter(private val Kilometre:  Array<String>, private val Runs: Array<Int>) :
            RecyclerView.Adapter<runnerAdater.RunsViewHolder>() {

            //View Holder to holder each items

            class RunsViewHolder(itemview: View) : RecyclerView.ViewHolder(itemsView) {
                val dayTextView: TextView = itemView.findViewById(dayTextView)
                val kilometreTextView: TextView = itemView.findViewById(kilometre)

            }

            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RunsViewHolder  {

                val view = LayoutInflater.from(parent.context)
                return RunsViewHolder(view)

            }

            override fun onCreateViewHolder(holder: RunsViewHolder,  position: Int  {

                holder.dayTextView.text = Runs[position]
                holder.kilometreTextView.text = Runs[position]



        }

    }
}