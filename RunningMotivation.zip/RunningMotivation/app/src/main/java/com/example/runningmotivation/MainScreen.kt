package com.example.runningmotivation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_screen)


        private val days = arrayOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
        private val screenTimes = IntArray(7) // Parallel array to store screen time
        private lateinit var inputFields: List<EditText>
        private lateinit var infoTextView: TextView



    }
}