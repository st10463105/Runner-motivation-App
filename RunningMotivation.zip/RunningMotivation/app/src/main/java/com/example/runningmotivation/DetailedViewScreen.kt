package com.example.runningmotivation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DetailedViewScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detailed_view_screen)
    }
}